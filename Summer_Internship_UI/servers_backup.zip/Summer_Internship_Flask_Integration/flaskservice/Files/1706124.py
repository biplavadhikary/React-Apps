### TODO: A utility class which will be created by the user , with Class name as " _[your roll number]" ,
# TODO: all transformations should be written inside a function which will be called inside the predict method

import pandas as pd
import numpy as np

class _1706124():

    ## TODO: Please note that document id should be present till the getPredictions method

    def __dropRedundantColumns(self, data):
        required_cols = ['pk_id', 'business_code', 'days_past_due_date', 'total_open_amount', 
                        'customer_payment_terms']
        newData = pd.DataFrame()
        for col in required_cols:
            newData[col] = data[col]
        return newData

    def __caculateRequiredFeatues(self,data):
        data['days_taken_to_pay'] = data['customer_payment_terms'] + data['days_past_due_date']
        data['has_exceeded_due'] = (data['days_past_due_date'] > 0).astype('int64')
        data.rename(columns = {'total_open_amount':'to_pay'}, inplace = True)
        data.rename(columns = {'days_past_due_date':'days_past_due_date'}, inplace = True)
        return data

    def __getScaledData(self, data, scaler):
        data['to_pay_scaled'] = scaler.transform(data[['to_pay']])
        return data

    def __getEncodedData(self, data, features):
        data = pd.get_dummies(data, columns = ['business_code'] , 
                            prefix_sep = "_", drop_first = True)

        data = data.reindex(columns = features, fill_value = 0)
        return data

    def __makePredictionTable(self, data, rfr, features, to_pay, pk_id):
        pred = rfr.predict(data[features])
        pred = np.round(np.clip(pred, a_min = 0, a_max = to_pay), 0)
        payment_types = (pred == to_pay).map({ True: 'Full Payment', False: 'Partial Payment' })

        return pd.DataFrame({'Pk Id': pk_id, 
                            #'To Pay': to_pay, 
                            'First Payment (Predicted)': pred, 
                            'Payment Type': payment_types })

    def getPredictions(self,data,model):
        print("You have reached me")

        features = model['features']
        scaler = model['scaler']
        rfr = model['rfr']

        data = self.__dropRedundantColumns(data) # not mandatory
        data = self.__caculateRequiredFeatues(data)
        data = self.__getScaledData(data, scaler)

        to_pay = data['to_pay']
        pk_id = data['pk_id']

        data = self.__getEncodedData(data, features)
        predData = self.__makePredictionTable(data, rfr, features, to_pay, pk_id)

        predData = predData.to_dict(orient="records")
        return predData
