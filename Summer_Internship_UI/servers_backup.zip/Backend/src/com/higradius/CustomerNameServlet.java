package com.higradius;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@WebServlet("/customerNameServlet")
public class CustomerNameServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger;
	final Connection con;
	
	static {
		logger = Logger.getLogger("Logger");
	}

    public CustomerNameServlet() {
        super();
        con = CustomerInvoiceDB.connectCustomerInvoiceDB();
    }

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
    	PrintWriter out;
    	
    	try {
    		out = response.getWriter();
    	} catch (IOException io) {
    		logger.severe("Unable to get Writer");
    		response.setStatus(HttpServletResponse.SC_EXPECTATION_FAILED);
			return;
    	}
		
		String data = getJSONData();
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		
		out.print(data);
		out.flush();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		doGet(request, response);
	}
	
	public String getJSONData() {
		String query = "SELECT customer_name, business_code, customer_number, SUM(total_open_amount) AS " + 
					"total_open_amount FROM customer_invoice GROUP BY customer_name;";
		
		List<CustomerName> customerList = null;
		try {
			customerList = RetrieveFromDB.retrieveCustomersList(con, query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().serializeNulls().create();
		return gson.toJson(customerList);
	}

}
