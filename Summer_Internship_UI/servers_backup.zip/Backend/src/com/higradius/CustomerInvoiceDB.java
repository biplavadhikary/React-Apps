package com.higradius;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerInvoiceDB {
	private static final String url = "jdbc:mysql://localhost:3306/project";
	private static final String uname = "root";
	private static final String pass = "root";
	private static final Logger logger;
	
	static {
		logger = Logger.getLogger("Logger");
		logger.setLevel(Level.ALL);
	}
	
	private CustomerInvoiceDB () {
		 throw new IllegalStateException("Utility class");
	}
	
	public static Connection connectCustomerInvoiceDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			logger.fine("SQL Driver Loaded Successfully");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
		Connection con;
		
		try {
			con = DriverManager.getConnection(url, uname, pass);
			logger.fine("Connection to Database Established! ");
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return con;
	}
	
}
