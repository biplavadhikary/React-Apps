package com.higradius;

public class NullTest {
	public static void main(String[] args) {
//		String str = "Hello,,Hi,,Yo";
//		
//		String words[] = str.split(",");
//		
//		for (String word : words) {
//			String isnull = word == null ? "True" : "False";
//			System.out.println("Word: " + word + " , Is null? " + isnull);
//		}
//		
//		String emptyString = " 1 ".trim();
//		System.out.println("Parse of Empty String: " + Integer.parseInt(emptyString));
	}
}
