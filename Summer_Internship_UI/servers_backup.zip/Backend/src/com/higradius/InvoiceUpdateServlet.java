package com.higradius;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/invoiceUpdateServlet")
public class InvoiceUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final Connection con;
	private static final Logger logger;
	
	static { 
		logger = Logger.getLogger("Logger");
		logger.setLevel(Level.ALL);
	}

    public InvoiceUpdateServlet() {
        super();
        con = CustomerInvoiceDB.connectCustomerInvoiceDB();
    }

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		String doctype = null;
		float total_open_amount = -1;
		int pk_id = 0;
		
		try {
			pk_id = Integer.parseInt(request.getParameter("pk_id"));
			doctype = request.getParameter("doctype");
			total_open_amount = Float.parseFloat(request.getParameter("total_open_amount"));
			updateToDB(pk_id, doctype, total_open_amount, response);
			response.setStatus(HttpServletResponse.SC_OK);
			
		} catch (NullPointerException npe) {
			// Expected if only one entry is changed or none
			// System.out.println(npe);
			updateToDB(pk_id, doctype, total_open_amount, response);
			response.setStatus(HttpServletResponse.SC_OK);
			
		} catch (NumberFormatException nfe) {
			logger.warning("Error: Invalid Number: " + nfe.getMessage());
			response.setStatus(HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE);
		}
		
		String updationData = "PK Id: " + pk_id + 
				", Doc-Type: " + doctype + 
				", Open Amount: " + total_open_amount;
		
		logger.info(updationData);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		doGet(request, response);
	}
	
	void updateToDB(int pk_id, String doctype, float total_open_amount, HttpServletResponse response) {
		String queryUpdateDT = "UPDATE customer_invoice SET doctype='" + 
				doctype + "' WHERE pk_id=" + pk_id;
		String queryUpdateOMT = "UPDATE customer_invoice SET actual_open_amount=" + 
				total_open_amount + " WHERE pk_id=" + pk_id;
		String queryUpdateBoth = "UPDATE customer_invoice SET doctype='" + 
				doctype + "' , actual_open_amount=" + total_open_amount + 
				" WHERE pk_id=" + pk_id;
		
		try (Statement st = con.createStatement()) {
			if (doctype != null) {
				if (total_open_amount != -1) {
					st.executeUpdate(queryUpdateBoth);
					logger.info("Updated Both");
				}
				else {
					st.executeUpdate(queryUpdateDT);
					logger.info("Updated Doc Type");
				}
			} else if (total_open_amount != -1) {
				st.executeUpdate(queryUpdateOMT);
				logger.info("Updated Total Open Amount");
			} else {
				logger.info("No Updation");
			}
			
		} catch(SQLException se) {
			logger.warning(se.getMessage());
			response.setStatus(HttpServletResponse.SC_EXPECTATION_FAILED);
		}
	}

}
