package com.higradius;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.google.gson.annotations.Expose;

public class CustomerInvoiceResponse {
	@Expose
	public String name;
	@Expose
	public Stats stats;
	@Expose
	public List <CustomerInvoice> invoiceList;
	
	public CustomerInvoiceResponse(Connection con, String[] queries, String name) {

		try {
			invoiceList = RetrieveFromDB.retrieveList(con, queries[0]);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		this.name = name == null ? "Copper" : name;
		
		stats = new Stats();
		stats.getAllStats(con, queries, name);
		
	}
}
