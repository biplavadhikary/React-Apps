package com.higradius;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CustomerName {
	
	@Expose @SerializedName("name_of_customer") private String customer_name;
	@Expose private String business_code;
	
	@Expose private int customer_number;
	@Expose private float total_open_amount;
	
	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public int getCustomer_number() {
		return customer_number;
	}
	
	public String getBusiness_code() {
		return business_code;
	}

	public void setBusiness_code(String business_code) {
		this.business_code = business_code;
	}

	public void setCustomer_number(int customer_number) {
		this.customer_number = customer_number;
	}

	public float getTotal_open_amount() {
		return total_open_amount;
	}

	public void setTotal_open_amount(float total_open_amount) {
		this.total_open_amount = total_open_amount;
	}
}
