package com.higradius;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReadCSVActual {
	private static final Logger logger;
	
	static {
		logger = Logger.getLogger("Logger");
		logger.setLevel(Level.ALL);
	}
	
	public static java.sql.Date parseDate(String dateString) throws ParseException {
		dateString = dateString.trim();
		
		try {
			return new java.sql.Date(
                ((java.util.Date) new SimpleDateFormat("MM/dd/yyyy").parse(dateString)).getTime()); 
		}
		catch(ParseException pe) {
			return null;
		}
		
	}
	
	public static int parseInt(String str) {
		str = str.trim();
		
		try {
			return Integer.parseInt(str);
		}
		catch (NumberFormatException nfe) {
			return Integer.MIN_VALUE;
		}
	}
	
	public static float parseFloat(String str) {
		str = str.trim();
		
		try {
			return Float.parseFloat(str);
		}
		catch (NumberFormatException nfe) {
			return Float.MIN_VALUE;
		}
	}
	
	public static CustomerInvoice createCustomerInvoice(String[] cells) throws ParseException {
		
		CustomerInvoice ci = new CustomerInvoice();
		
		//System.out.println("Adding a Record: Total: " + cells.length + " fields");
		
		ci.setPk_id();
		ci.setAcct_doc_header_id(parseInt(cells[0]));
		ci.setCompany_id(parseInt(cells[1]));
		ci.setDocument_number(parseInt(cells[2]));
		ci.setDocument_number_norm(parseInt(cells[3]));
		ci.setBusiness_code(cells[4]);
		ci.setCreate_year(cells[5]);
		ci.setDocument_line_number(parseInt(cells[6]));
		ci.setDoctype(cells[7]);
		ci.setCustomer_number(parseInt(cells[8]));
		ci.setCustomer_number_norm(parseInt(cells[9]));
		ci.setFk_customer_map_id(parseInt(cells[10]));
		ci.setCustomer_name(cells[11]);
		ci.setDivision(cells[12]);
		ci.setDocument_create_date(parseDate(cells[13]));
		ci.setDocument_create_date_norm(parseDate(cells[14]));
		ci.setPosting_date(parseDate(cells[15]));
		ci.setPosting_date_norm(parseDate(cells[16]));
		ci.setPosting_id(cells[17]);
		ci.setDue_date(parseDate(cells[18]));
		ci.setDue_date_norm(parseDate(cells[19]));
		ci.setOrder_date(parseDate(cells[20]));
		ci.setOrder_date_norm(parseDate(cells[21]));
		ci.setInvoice_id(parseInt(cells[22]));
		ci.setInvoice_id_norm(parseInt(cells[23]));
		ci.setBaseline_create_date(parseDate(cells[24]));
		ci.setInvoice_date_norm(parseDate(cells[25]));
		ci.setTotal_open_amount(parseFloat(cells[26]));
		ci.setTotal_open_amount_norm(parseFloat(cells[27]));
		ci.setCust_payment_terms(parseInt(cells[28]));
		ci.setBusiness_area(cells[29]);
		ci.setShip_date(parseDate(cells[30]));
		ci.setShip_to(cells[31]);
		ci.setClearing_date(parseDate(cells[32]));
		ci.setClearing_date_norm(parseDate(cells[33]));
		ci.setReason_code(cells[34]);
		ci.setIsOpen(parseInt(cells[35]));
		ci.setDiscount_due_date_norm(parseDate(cells[36]));
		ci.setDebit_credit_indicator(cells[37]);
		ci.setPayment_method(cells[38]);
		ci.setDocument_creation_date(parseDate(cells[39]));
		ci.setInvoice_amount_doc_currency(parseFloat(cells[40]));
		ci.setDocument_id(parseInt(cells[41]));
		ci.setActual_open_amount(parseFloat(cells[42]));
		ci.setPaid_amount(parseFloat(cells[43]));
		ci.setDayspast_due(parseInt(cells[44]));
		ci.setInvoice_age(parseInt(cells[45]));
		
		
		// if last column is blank, it will read 46 columns
		if(cells.length == 46) {
			ci.setDisputed_amount(Float.MIN_VALUE);
		}
		// otherwise there will be 47 columns
		else {
			ci.setDisputed_amount(parseFloat(cells[46]));
		}
		
		//System.out.println("Added Record");
		
        return ci;
    }

	public static List<CustomerInvoice> readInvoicesFromCSV(String fileName) throws ParseException {
		
		List<CustomerInvoice> invoices = new ArrayList<>();
		//Path pathToFile = Paths.get(fileName);
		long count = 0;
		
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			
			 String line = br.readLine();
			 line = br.readLine();
			 
			 while (line != null) {
				 String[] attributes = line.split(",");
				 
				 CustomerInvoice invoice = createCustomerInvoice(attributes);
				 invoices.add(invoice);
				 
				 line = br.readLine();
				 count += 1;
			 }
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}
		
		String parseSuccessMessage = "Succesfully Parsed " + count + " Records";
		logger.info(parseSuccessMessage);
		return invoices;
	}
	
	public static void addToDatabase(List<CustomerInvoice> invoices) throws SQLException {
		int batchSize = 1000; 
		int count = 0;
		
		Connection con = CustomerInvoiceDB.connectCustomerInvoiceDB();
		
		String insertQeury = "INSERT INTO customer_invoice (pk_id, acct_doc_header_id, company_id, "
				+ "document_number, document_number_norm, business_code, create_year, "
				+ "document_line_number, doctype, customer_number, customer_number_norm, "
                + "fk_customer_map_id, customer_name, division, document_create_date, "
				+ "document_create_date_norm, posting_date, posting_date_norm, posting_id, "
                + "due_date, due_date_norm, order_date, order_date_norm, invoice_id, invoice_id_norm, "
				+ "baseline_create_date, invoice_date_norm, total_open_amount, total_open_amount_norm, "
                + "cust_payment_terms, business_area, ship_date, ship_to, clearing_date, clearing_date_norm, "
				+ "reason_code, isOpen, discount_due_date_norm, debit_credit_indicator, payment_method, "
                + "document_creation_date, invoice_amount_doc_currency, document_id, actual_open_amount, "
				+ "paid_amount, dayspast_due, invoice_age, disputed_amount) "
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"
				+ "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		try (PreparedStatement statement = con.prepareStatement(insertQeury)) {
			for(CustomerInvoice invoice : invoices) {
				
				//System.out.println(invoice);
				//System.out.println("Trying to Add this Invoice");
				
				statement.setInt(1, invoice.getPk_id());
				
				if (!invoice.checkNullAcct_doc_header_id()) statement.setInt(2, invoice.getAcct_doc_header_id());
				else statement.setNull(2, Types.NULL);
				
				if (!invoice.checkNullCompany_id()) statement.setInt(3, invoice.getCompany_id());
				else statement.setNull(3, Types.NULL);
				
				if (!invoice.checkNullDocument_number()) statement.setInt(4, invoice.getDocument_number());
				else statement.setNull(4, Types.NULL);
				
				if (!invoice.checkNullDocument_number_norm()) statement.setInt(5, invoice.getDocument_number_norm());
				else statement.setNull(5, Types.NULL);
				
				statement.setString(6, invoice.getBusiness_code());
				statement.setString(7, invoice.getCreate_year());
				
				if (!invoice.checkNullDocument_line_number()) statement.setInt(8, invoice.getDocument_line_number());
				else statement.setNull(8, Types.NULL);
				
				statement.setString(9, invoice.getDoctype());
				
				if (!invoice.checkNullCustomer_number()) statement.setInt(10, invoice.getCustomer_number());
				else statement.setNull(10, Types.NULL);
				
				if (!invoice.checkNullCustomer_number_norm()) statement.setInt(11, invoice.getCustomer_number_norm());
				else statement.setNull(11, Types.NULL);
				
				if (!invoice.checkNullFk_customer_map_id()) statement.setInt(12, invoice.getFk_customer_map_id());
				else statement.setNull(12, Types.NULL);
				
				statement.setString(13, invoice.getCustomer_name());
				statement.setString(14, invoice.getDivision());
				statement.setDate(15, invoice.getDocument_create_date());
				statement.setDate(16, invoice.getDocument_create_date_norm());
				statement.setDate(17, invoice.getPosting_date());
				statement.setDate(18, invoice.getPosting_date_norm());
				statement.setString(19, invoice.getPosting_id());
				statement.setDate(20, invoice.getDue_date());
				statement.setDate(21, invoice.getDue_date_norm());
				statement.setDate(22, invoice.getOrder_date());
				statement.setDate(23, invoice.getOrder_date_norm());
				
				if (!invoice.checkNullInvoice_id()) statement.setInt(24, invoice.getInvoice_id());
				else statement.setNull(24, Types.NULL);
				
				if (!invoice.checkNullInvoice_id_norm()) statement.setInt(25, invoice.getInvoice_id_norm());
				else statement.setNull(25, Types.NULL);
				
				statement.setDate(26, invoice.getBaseline_create_date());
				statement.setDate(27, invoice.getInvoice_date_norm());
				
				if (!invoice.checkNullTotal_open_amount()) statement.setFloat(28, invoice.getTotal_open_amount());
				else statement.setNull(28, Types.NULL);
				
				if(!invoice.checkNullTotal_open_amount_norm()) statement.setFloat(29, invoice.getTotal_open_amount_norm());
				else statement.setNull(29, Types.NULL);
				
				
				if (!invoice.checkNullCust_payment_terms()) statement.setInt(30, invoice.getCust_payment_terms());
				else statement.setNull(30, Types.NULL);
				
				statement.setString(31, invoice.getBusiness_area());
				statement.setDate(32, invoice.getShip_date());
				statement.setString(33, invoice.getShip_to());
				statement.setDate(34, invoice.getClearing_date());
				statement.setDate(35, invoice.getClearing_date_norm());
				statement.setString(36, invoice.getReason_code());
				
				if (!invoice.checkNullIsOpen()) statement.setInt(37,  invoice.getIsOpen());
				else statement.setNull(37, Types.NULL);
				
				statement.setDate(38, invoice.getDiscount_due_date_norm());
				statement.setString(39, invoice.getDebit_credit_indicator());
				statement.setString(40, invoice.getPayment_method());
				statement.setDate(41, invoice.getDocument_creation_date());
				
				if (!invoice.checkNullInvoice_amount_doc_currency()) statement.setFloat(42, invoice.getInvoice_amount_doc_currency());
				else statement.setNull(42, Types.NULL);
				
				if (!invoice.checkNullDocument_id()) statement.setInt(43, invoice.getDocument_id());
				else statement.setNull(43, Types.NULL);
				
				if (!invoice.checkNullActual_open_amount()) statement.setFloat(44, invoice.getActual_open_amount());
				else statement.setNull(44, Types.NULL);
				
				if(!invoice.checkNullPaid_amount()) statement.setFloat(45, invoice.getPaid_amount());
				else statement.setNull(45, Types.NULL);
				
				if (!invoice.checkNullDayspast_due()) statement.setInt(46, invoice.getDayspast_due());
				else statement.setNull(46, Types.NULL);
				
				if (!invoice.checkNullInvoice_age()) statement.setInt(47, invoice.getInvoice_age());
				else statement.setNull(47, Types.NULL);
				
				if (!invoice.checkNullDisputed_amount()) statement.setFloat(48, invoice.getDisputed_amount());
				else statement.setNull(48, Types.NULL);
				
				statement.addBatch();
				
				++count;
				
	            if (count % batchSize == 0) {
	                statement.executeBatch();
	                String totalCountMessage = "Batched Added: Total " + count + " Records! ";
	                logger.info(totalCountMessage);
	            }
				
			}
			
			statement.executeBatch();
	        logger.info("Batched Added!");
	        String successMessage = "Sucessfully Added all " + count +  " Records to Database! ";
			logger.info(successMessage);
		}
	}
	
	public static void main(String[] args) throws ParseException, SQLException {
		
		logger.info("Working Directory: " + System.getProperty("user.dir"));
		
		String csvFile = "src\\com\\higradius\\Data Uploading Full.csv";
		
		logger.info("Initiating Parse Process");
		List<CustomerInvoice> invoices = readInvoicesFromCSV(csvFile);
		
//		for(CustomerInvoice invoice : invoices) {
//			System.out.println(invoice);
//		}
		
		addToDatabase(invoices);
	}
}
