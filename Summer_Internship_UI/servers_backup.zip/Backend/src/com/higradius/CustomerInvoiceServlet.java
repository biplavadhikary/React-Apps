package com.higradius;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@WebServlet("/customerInvoiceServlet")
public class CustomerInvoiceServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger;
	private final Connection con;

    public CustomerInvoiceServlet() {
        super();
        con = CustomerInvoiceDB.connectCustomerInvoiceDB();
    }
    static {
    	logger = Logger.getLogger("Logger");
    	logger.setLevel(Level.ALL);
    }
    
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		
    	String id = null; 
		String advOp = null; 
		String advAmt = null;
		int limit;
		PrintWriter out=null;
		
		try {
			id = request.getParameter("id").toLowerCase();
			advOp = request.getParameter("advOperation").toLowerCase();
			advAmt = request.getParameter("advAmount");
			
		} catch (NullPointerException npe) {
			if (id == null) {
				logger.log(Level.WARNING, "No Id Param Specified - Sending Data for All Customers");
				id = "all";
			}
		}

		try {
			out = response.getWriter();
		} catch (IOException io) {
			logger.log(Level.SEVERE, "Some I/O Exception Occured");
			response.setStatus(HttpServletResponse.SC_EXPECTATION_FAILED);
			return;
		}
		
		try {
			limit = Integer.parseInt(request.getParameter("limit"));
		}
		catch(Exception e) {
			logger.log(Level.INFO, "No Limit Param Specified - Sending First 100 Results");
			limit = 100;
		}
		
		String data = getJSONData(id, limit, advOp, advAmt);
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		
		out.print(data);
		response.setStatus(HttpServletResponse.SC_OK);
		out.flush();
	}
    
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
    	doGet(request, response);
	}
	
	public String getJSONData(String id, int limit, String advOp, String advAmt) {
		
		String[] queries = getQueries(id, limit, advOp, advAmt);
		
		CustomerInvoiceResponse resp = new CustomerInvoiceResponse(con, queries, id);
		
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().serializeNulls().create();
		return gson.toJson(resp);
	}
	
	public String[] getQueries(String id, int limit, String advOp, String advAmt) {
		String[] queries = new String[5];
		
		if (id == null || id.equals("all")) {
			queries[0] = "SELECT * FROM customer_invoice WHERE isOpen=1 LIMIT " + limit ;
			queries[1] = "SELECT COUNT(DISTINCT customer_number) AS total_customer FROM customer_invoice";
			queries[2] = "SELECT SUM(total_open_amount) AS total_open_AR FROM customer_invoice";
			queries[3] = "SELECT ROUND(AVG(cust_payment_terms + dayspast_due)) AS average_days_delay FROM customer_invoice";
			queries[4] = "SELECT COUNT(*) AS total_open_invoices FROM customer_invoice WHERE isOpen = 1";
		}
		else {
			queries[0] = "SELECT * FROM customer_invoice WHERE customer_number='" + id +"' LIMIT " + limit;
			queries[1] = "SELECT COUNT(DISTINCT customer_name) AS total_customer FROM customer_invoice WHERE customer_number='" + id + "'" ;
			queries[2] = "SELECT SUM(total_open_amount) AS total_open_AR FROM customer_invoice WHERE customer_number='" + id + "'";
			queries[3] = "SELECT ROUND(AVG(cust_payment_terms + dayspast_due)) AS average_days_delay FROM customer_invoice WHERE customer_number='" + id + "'";
			queries[4] = "SELECT COUNT(*) AS total_open_invoices FROM customer_invoice WHERE isOpen = 1 AND customer_number='" + id + "'";
		}
		
		if (advOp != null) queries[0] = updateQueryForAdvancedSearch(advOp, advAmt, limit);
		
		return queries;
	}
	
	public String updateQueryForAdvancedSearch(String advOp, String advAmt, int limit) {
		String toDo = "You asked for: Advanced Operation: " + advOp + ", Amount: " + advAmt;
		logger.log(Level.INFO, "I got your Query in Advanced Search");
		logger.log(Level.INFO, toDo);
		
		String symbol = advOp;
		
		return  "SELECT * FROM customer_invoice WHERE total_open_amount " + symbol 
						+ " " + advAmt + " LIMIT " + limit;
	}

}
