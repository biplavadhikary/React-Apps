package com.higradius;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.gson.annotations.Expose;

public class Stats {
	private static final Logger logger;
	
	static {
		logger = Logger.getLogger("Logger");
		logger.setLevel(Level.ALL);
	}
	
	@Expose public int total_customer;
	@Expose public int total_open_AR; 
	@Expose public int average_days_delay; 
	@Expose public int total_open_invoices;
	
	public void getAllStats(Connection con, String[] queries, String name) {
		Statement st=null;
		
		try {
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		total_open_AR = getStat(queries[2], "total_open_AR", st);
		total_open_invoices = getStat(queries[4], "total_open_invoices", st);
		total_customer = 1;
		average_days_delay = getStat(queries[3], "average_days_delay", st);
		
		/* to be generated on first request only (ie, for all Customers) */
		if(name.equals("all")) {
			total_customer = getStat(queries[1], "total_customer", st);
		}
		
		logger.info("Successfully Generated Stats");
	}
	
	public int getStat(String query, String param, Statement st) {
		try (ResultSet res = st.executeQuery(query);) {
			res.next();
			return res.getInt(param);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
	}
}
}
