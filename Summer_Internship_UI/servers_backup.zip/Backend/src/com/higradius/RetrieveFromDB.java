package com.higradius;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class RetrieveFromDB {
	private static final Logger logger;
	
	static {
		logger = Logger.getLogger("Logger");
		logger.setLevel(Level.ALL);
	}
	
	private RetrieveFromDB () {
		 throw new IllegalStateException("Utility class");
	}
	
	public static List<CustomerInvoice> putResultsToList(ResultSet res) throws SQLException {
		List <CustomerInvoice> list = new ArrayList <>();
		
		if(!res.isBeforeFirst()) {    
		    logger.info("No Records are Found!"); 
		}
		
		else {
			while (res.next()) {
				
				CustomerInvoice ci = new CustomerInvoice();
				
				ci.setPk_id(res.getInt("pk_id"));
				ci.setAcct_doc_header_id(res.getInt("acct_doc_header_id"));
				ci.setCompany_id(res.getInt("company_id"));
				ci.setDocument_number(res.getInt("document_number"));
				ci.setDocument_number_norm(res.getInt("document_number_norm"));
				ci.setBusiness_code(res.getString("business_code"));
				ci.setCreate_year(res.getString("create_year"));
				ci.setDocument_line_number(res.getInt("Document_line_number"));
				ci.setDoctype(res.getString("doctype"));
				ci.setCustomer_number(res.getInt("customer_number"));
				ci.setCustomer_number_norm(res.getInt("Customer_number_norm"));
				ci.setFk_customer_map_id(res.getInt("fk_customer_map_id"));
				ci.setCustomer_name(res.getString("customer_name"));
				ci.setDivision(res.getString("division"));
				ci.setDocument_create_date(res.getDate("document_create_date"));
				ci.setDocument_create_date_norm(res.getDate("document_create_date_norm"));
				ci.setPosting_date(res.getDate("posting_date"));
				ci.setPosting_date_norm(res.getDate("posting_date_norm"));
				ci.setPosting_id(res.getString("posting_id"));
				ci.setDue_date(res.getDate("due_date"));
				ci.setDue_date_norm(res.getDate("due_date_norm"));
				ci.setOrder_date(res.getDate("order_date"));
				ci.setOrder_date_norm(res.getDate("order_date_norm"));
				ci.setInvoice_id(res.getInt("invoice_id"));
				ci.setInvoice_id_norm(res.getInt("invoice_id_norm"));
				ci.setBaseline_create_date(res.getDate("baseline_create_date"));
				ci.setInvoice_date_norm(res.getDate("invoice_date_norm"));
				ci.setTotal_open_amount(res.getFloat("total_open_amount"));
				ci.setTotal_open_amount_norm(res.getFloat("total_open_amount_norm"));
				ci.setCust_payment_terms(res.getInt("cust_payment_terms"));
				ci.setBusiness_area(res.getString("business_area"));
				ci.setShip_date(res.getDate("ship_date"));
				ci.setShip_to(res.getString("ship_to"));
				ci.setClearing_date(res.getDate("clearing_date"));
				ci.setClearing_date_norm(res.getDate("clearing_date_norm"));
				ci.setReason_code(res.getString("reason_code"));
				ci.setIsOpen(res.getInt("isOpen"));
				ci.setDiscount_due_date_norm(res.getDate("discount_due_date_norm"));
				ci.setDebit_credit_indicator(res.getString("debit_credit_indicator"));
				ci.setPayment_method(res.getString("payment_method"));
				ci.setDocument_creation_date(res.getDate("document_creation_date"));
				ci.setInvoice_amount_doc_currency(res.getFloat("invoice_amount_doc_currency"));
				ci.setDocument_id(res.getInt("document_id"));
				ci.setActual_open_amount(res.getFloat("actual_open_amount"));
				ci.setPaid_amount(res.getFloat("paid_amount"));
				ci.setDayspast_due(res.getInt("dayspast_due"));
				ci.setInvoice_age(res.getInt("invoice_age"));
				
				list.add(ci);
			}
		}
		
		return list;
	}
	
	public static List <CustomerInvoice> retrieveList(Connection con, String query) throws SQLException {
		List <CustomerInvoice> list = null;
		
		try (Statement st = con.createStatement()) {
			ResultSet res = st.executeQuery(query);
			list = putResultsToList(res);
			logger.info("Successfully Retrieved Data from DB");
		}
		
		return list;
	}
	
	public static List<CustomerName> putCustomerResultsToList(ResultSet res) throws SQLException {
		List <CustomerName> list = new ArrayList <>();
		
		if(!res.isBeforeFirst()) {    
		    logger.info("No Records are Found!"); 
		}
		
		else {
			while (res.next()) {
				
				CustomerName ci = new CustomerName();
				
				ci.setCustomer_number(res.getInt("customer_number"));
				ci.setCustomer_name(res.getString("customer_name"));
				ci.setTotal_open_amount(res.getFloat("total_open_amount"));
				ci.setBusiness_code(res.getString("business_code"));
				
				list.add(ci);
			}
		}
		
		return list;
	}
	
	public static List <CustomerName> retrieveCustomersList(Connection con, String query) throws SQLException {
		List <CustomerName> list = null;
		
		try (Statement st = con.createStatement()){
			ResultSet res = st.executeQuery(query);
			list = putCustomerResultsToList(res);
			logger.info("Successfully Retrieved Data from DB");
		}
		
		return list;
	}
	
	public static void displayLists(List<CustomerInvoice> list) {
		for (CustomerInvoice ci : list) {
			String ciStr = ci.toString();
			logger.info(ciStr);
		}
	}
	
//	public static void main(String[] args) throws SQLException {
//		Connection con = CustomerInvoiceDB.connectCustomerInvoiceDB();
//		String query = "SELECT * FROM customer_invoice LIMIT 100";
//		
//		ArrayList <CustomerInvoice> list = retrieveList(con, query);
//		
//		if (!list.isEmpty()) {
//			System.out.printf("\nThe Records are as follows: \n");
//			displayLists(list);			
//		}
//	}
}
