export const SERVER_URL = 'http://localhost:8082/';
export const ROLL_NUMBER = '1706124';