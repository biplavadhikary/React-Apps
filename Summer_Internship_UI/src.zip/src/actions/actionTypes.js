export const UPDATE_DASHBOARD = "updateDashboard"
export const CREATE_DASHBOARD = "createDashboard"