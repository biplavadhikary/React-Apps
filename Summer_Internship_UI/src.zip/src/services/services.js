import axios from 'axios';
import { SERVER_URL,ROLL_NUMBER } from '../utils/constants';


export function serviceCall() {
  return axios.post(`${SERVER_URL}`);
}

export function callDummyAPI(name) {
  //console.log(`Server URL: ${SERVER_URL}${ROLL_NUMBER}/dummy.do?`);
  return axios.post(
    `${SERVER_URL}${ROLL_NUMBER}/customerInvoiceServlet`,
    {},
    {
      headers: { 'Content-Type': 'application/json' },
      params: { name: name, limit: 100 },
    }
  );
}
